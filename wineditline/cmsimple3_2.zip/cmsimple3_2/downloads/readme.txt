The downloads folder stores all the files you wish to make available for the user to download.

How to inserting a link to download a file:

1. You must first upload your file from your local machine. It goes in a folder called 'download'.
- In the editor menu choose [DOWNLOADS]. 
- Click the browse button, select the file, and click upload.

2. Highlight some text or an image.

3. Use the text box on the top left of the editor to select the file. It will be at the end of the list, after the < H1>-< H3> names. Click on the icon next to it, and the link will appear in your page.