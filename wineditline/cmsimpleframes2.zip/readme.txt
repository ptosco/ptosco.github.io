this template for cmsimple.dk was downloaded from www.cmsimple-styles.com

please do not remove the links on the template!
if you want to remove them, buy a template license!
please visit www.cmsimple-styles.com for more information...

installation:
-------------

1. unzip the file and retain the directory structure exactly as it is and you will
   then be left with 1 folder, which contains a few folders and files.

2. upload this folder exactly as you see it into the templates folder of your cmsimple
   installation.

3. login to your website and goto:
   >> settings >> edit configuration
   You should then see some options.
 
4. under the section "site" you will see that there is a drop down box to choose a
   template that is available in your templates directory. just select the template
   name that you have installed, then scroll down and save.

5. The process should now be complete. just logout and you will now see the new template
   for your site.

   remember to make sure the following files are writable on your host / server:

a. template.htm
b. stylesheet.css


important:
----------

the templates get updated and bugs fixed.
if your template has bugs or shows unwanted behaviours,
check my site to see if it got updated!


creating templates is fun but much work!
if you like my templates and use them on commercial websites please donate!

if you want to remove the links you need to buy a license. there is no excuse for removing them!

need a custom template for your company / club / private website?
contact me at: jensbroecher@gmail.com
